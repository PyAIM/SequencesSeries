// JavaScript for the Sequences page interactive elements

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the interactive sequence visualizer if it exists on the page
    initSequenceVisualizer();
});

function initSequenceVisualizer() {
    const visualizerContainer = document.getElementById('interactive-sequence-graph');
    if (!visualizerContainer) return;
    
    const sequenceSelect = document.getElementById('sequence-select');
    const termsSlider = document.getElementById('terms-slider');
    const termsValue = document.getElementById('terms-value');
    
    // Update the terms value display when the slider changes
    if (termsSlider && termsValue) {
        termsSlider.addEventListener('input', function() {
            termsValue.textContent = this.value;
            updateSequenceVisualization();
        });
    }
    
    // Update the visualization when the sequence type changes
    if (sequenceSelect) {
        sequenceSelect.addEventListener('change', function() {
            updateSequenceVisualization();
        });
    }
    
    // Initial visualization
    updateSequenceVisualization();
}

function updateSequenceVisualization() {
    const sequenceSelect = document.getElementById('sequence-select');
    const termsSlider = document.getElementById('terms-slider');
    const sequenceFormula = document.getElementById('sequence-formula');
    const sequenceConvergence = document.getElementById('sequence-convergence');
    
    if (!sequenceSelect || !termsSlider) return;
    
    const sequenceType = sequenceSelect.value;
    const numTerms = parseInt(termsSlider.value);
    
    // Generate sequence data based on the selected type
    let sequenceData = [];
    let sequenceFunction;
    let convergenceValue = '';
    let formulaText = '';
    
    switch (sequenceType) {
        case '1': // Arithmetic sequence
            sequenceFunction = n => 2 + 3 * n;
            formulaText = 'a_n = 2 + 3n';
            convergenceValue = 'Diverges to ∞';
            break;
        case '2': // Geometric sequence
            sequenceFunction = n => 3 * Math.pow(0.5, n);
            formulaText = 'a_n = 3 · (1/2)^n';
            convergenceValue = 'Converges to 0';
            break;
        case '3': // Harmonic sequence
            sequenceFunction = n => 1 / (n + 1);
            formulaText = 'a_n = 1/(n+1)';
            convergenceValue = 'Converges to 0';
            break;
        case '4': // Fibonacci sequence
            sequenceFunction = n => {
                if (n === 0) return 0;
                if (n === 1) return 1;
                
                let a = 0, b = 1, temp;
                for (let i = 2; i <= n; i++) {
                    temp = a + b;
                    a = b;
                    b = temp;
                }
                return b;
            };
            formulaText = 'F_n = F_{n-1} + F_{n-2}, F_0 = 0, F_1 = 1';
            convergenceValue = 'Diverges to ∞';
            break;
        case '5': // Alternating sequence
            sequenceFunction = n => Math.pow(-1, n) / (n + 1);
            formulaText = 'a_n = (-1)^n/(n+1)';
            convergenceValue = 'Converges to 0';
            break;
        default:
            sequenceFunction = n => n;
            formulaText = 'a_n = n';
            convergenceValue = 'Diverges to ∞';
    }
    
    // Generate sequence points
    const points = [];
    for (let i = 0; i < numTerms; i++) {
        points.push({ x: i, y: sequenceFunction(i) });
    }
    
    // Update the visualization
    createLineChart('interactive-sequence-graph', [
        { name: 'Sequence', points: points }
    ], {
        xLabel: 'n',
        yLabel: 'a_n',
        width: document.getElementById('interactive-sequence-graph').clientWidth
    });
    
    // Update the information display
    if (sequenceFormula) {
        sequenceFormula.textContent = `Formula: ${formulaText}`;
    }
    
    if (sequenceConvergence) {
        sequenceConvergence.textContent = `Convergence: ${convergenceValue}`;
    }
}
