// Main JavaScript file for the Calculus Explorer website

// Mobile navigation toggle
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const nav = document.querySelector('nav');
    
    if (hamburger) {
        hamburger.addEventListener('click', function() {
            this.classList.toggle('active');
            nav.classList.toggle('active');
        });
    }
    
    // Solution toggle for exercises
    const solutionButtons = document.querySelectorAll('.toggle-solution');
    
    solutionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const solution = this.nextElementSibling;
            if (solution.style.display === 'none' || solution.style.display === '') {
                solution.style.display = 'block';
                this.textContent = 'Hide Solution';
            } else {
                solution.style.display = 'none';
                this.textContent = 'Show Solution';
            }
        });
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Initialize MathJax if it's loaded (MathJax v3 configuration)
    if (typeof MathJax !== 'undefined') {
        if (MathJax.version && MathJax.version[0] === '3') {
            // MathJax v3
            MathJax.typeset();
        } else if (MathJax.Hub) {
            // MathJax v2 fallback
            MathJax.Hub.Queue(["Typeset", MathJax.Hub]);
        }
    }
});

// Function to create a simple line chart
function createLineChart(containerId, data, options = {}) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    // Clear previous content
    container.innerHTML = '';
    
    // Set default options
    const defaultOptions = {
        width: container.clientWidth,
        height: 400,
        marginTop: 20,
        marginRight: 30,
        marginBottom: 50,
        marginLeft: 60,
        xLabel: 'x',
        yLabel: 'y',
        lineColors: ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6']
    };
    
    const chartOptions = { ...defaultOptions, ...options };
    
    // Create SVG element
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', chartOptions.width);
    svg.setAttribute('height', chartOptions.height);
    svg.style.overflow = 'visible';
    container.appendChild(svg);
    
    // Calculate chart dimensions
    const chartWidth = chartOptions.width - chartOptions.marginLeft - chartOptions.marginRight;
    const chartHeight = chartOptions.height - chartOptions.marginTop - chartOptions.marginBottom;
    
    // Find min and max values for x and y
    let xMin = Infinity, xMax = -Infinity;
    let yMin = Infinity, yMax = -Infinity;
    
    data.forEach(series => {
        series.points.forEach(point => {
            xMin = Math.min(xMin, point.x);
            xMax = Math.max(xMax, point.x);
            yMin = Math.min(yMin, point.y);
            yMax = Math.max(yMax, point.y);
        });
    });
    
    // Add some padding to y-axis
    const yPadding = (yMax - yMin) * 0.1;
    yMin -= yPadding;
    yMax += yPadding;
    
    // Create scales
    const xScale = value => chartOptions.marginLeft + (value - xMin) / (xMax - xMin) * chartWidth;
    const yScale = value => chartOptions.marginTop + chartHeight - (value - yMin) / (yMax - yMin) * chartHeight;
    
    // Draw axes
    const xAxis = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    xAxis.setAttribute('x1', chartOptions.marginLeft);
    xAxis.setAttribute('y1', yScale(0) || chartOptions.marginTop + chartHeight);
    xAxis.setAttribute('x2', chartOptions.marginLeft + chartWidth);
    xAxis.setAttribute('y2', yScale(0) || chartOptions.marginTop + chartHeight);
    xAxis.setAttribute('stroke', '#333');
    xAxis.setAttribute('stroke-width', 1);
    svg.appendChild(xAxis);
    
    const yAxis = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    yAxis.setAttribute('x1', xScale(0) || chartOptions.marginLeft);
    yAxis.setAttribute('y1', chartOptions.marginTop);
    yAxis.setAttribute('x2', xScale(0) || chartOptions.marginLeft);
    yAxis.setAttribute('y2', chartOptions.marginTop + chartHeight);
    yAxis.setAttribute('stroke', '#333');
    yAxis.setAttribute('stroke-width', 1);
    svg.appendChild(yAxis);
    
    // Draw x-axis ticks and labels
    const xTicks = 5;
    for (let i = 0; i <= xTicks; i++) {
        const x = xMin + (xMax - xMin) * (i / xTicks);
        const xPos = xScale(x);
        
        // Draw tick
        const tick = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        tick.setAttribute('x1', xPos);
        tick.setAttribute('y1', chartOptions.marginTop + chartHeight);
        tick.setAttribute('x2', xPos);
        tick.setAttribute('y2', chartOptions.marginTop + chartHeight + 5);
        tick.setAttribute('stroke', '#333');
        tick.setAttribute('stroke-width', 1);
        svg.appendChild(tick);
        
        // Draw label
        const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        label.setAttribute('x', xPos);
        label.setAttribute('y', chartOptions.marginTop + chartHeight + 20);
        label.setAttribute('text-anchor', 'middle');
        label.setAttribute('font-size', '12px');
        label.textContent = x.toFixed(1);
        svg.appendChild(label);
    }
    
    // Draw y-axis ticks and labels
    const yTicks = 5;
    for (let i = 0; i <= yTicks; i++) {
        const y = yMin + (yMax - yMin) * (i / yTicks);
        const yPos = yScale(y);
        
        // Draw tick
        const tick = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        tick.setAttribute('x1', chartOptions.marginLeft - 5);
        tick.setAttribute('y1', yPos);
        tick.setAttribute('x2', chartOptions.marginLeft);
        tick.setAttribute('y2', yPos);
        tick.setAttribute('stroke', '#333');
        tick.setAttribute('stroke-width', 1);
        svg.appendChild(tick);
        
        // Draw label
        const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        label.setAttribute('x', chartOptions.marginLeft - 10);
        label.setAttribute('y', yPos + 4);
        label.setAttribute('text-anchor', 'end');
        label.setAttribute('font-size', '12px');
        label.textContent = y.toFixed(1);
        svg.appendChild(label);
    }
    
    // Draw axis labels
    const xLabelElement = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    xLabelElement.setAttribute('x', chartOptions.marginLeft + chartWidth / 2);
    xLabelElement.setAttribute('y', chartOptions.marginTop + chartHeight + 40);
    xLabelElement.setAttribute('text-anchor', 'middle');
    xLabelElement.setAttribute('font-size', '14px');
    xLabelElement.textContent = chartOptions.xLabel;
    svg.appendChild(xLabelElement);
    
    const yLabelElement = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    yLabelElement.setAttribute('x', -chartOptions.marginTop - chartHeight / 2);
    yLabelElement.setAttribute('y', chartOptions.marginLeft - 40);
    yLabelElement.setAttribute('text-anchor', 'middle');
    yLabelElement.setAttribute('font-size', '14px');
    yLabelElement.setAttribute('transform', 'rotate(-90)');
    yLabelElement.textContent = chartOptions.yLabel;
    svg.appendChild(yLabelElement);
    
    // Draw data series
    data.forEach((series, seriesIndex) => {
        // Create path for the line
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        let pathData = '';
        
        series.points.forEach((point, pointIndex) => {
            const x = xScale(point.x);
            const y = yScale(point.y);
            
            if (pointIndex === 0) {
                pathData += `M ${x} ${y}`;
            } else {
                pathData += ` L ${x} ${y}`;
            }
        });
        
        path.setAttribute('d', pathData);
        path.setAttribute('fill', 'none');
        path.setAttribute('stroke', chartOptions.lineColors[seriesIndex % chartOptions.lineColors.length]);
        path.setAttribute('stroke-width', 2);
        svg.appendChild(path);
        
        // Add data points
        series.points.forEach(point => {
            const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('cx', xScale(point.x));
            circle.setAttribute('cy', yScale(point.y));
            circle.setAttribute('r', 3);
            circle.setAttribute('fill', chartOptions.lineColors[seriesIndex % chartOptions.lineColors.length]);
            svg.appendChild(circle);
        });
    });
    
    // Add legend if there are multiple series
    if (data.length > 1) {
        const legendY = chartOptions.marginTop + 20;
        const legendX = chartOptions.marginLeft + chartWidth - 100;
        
        data.forEach((series, index) => {
            // Legend line
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', legendX);
            line.setAttribute('y1', legendY + index * 20);
            line.setAttribute('x2', legendX + 20);
            line.setAttribute('y2', legendY + index * 20);
            line.setAttribute('stroke', chartOptions.lineColors[index % chartOptions.lineColors.length]);
            line.setAttribute('stroke-width', 2);
            svg.appendChild(line);
            
            // Legend text
            const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            text.setAttribute('x', legendX + 25);
            text.setAttribute('y', legendY + index * 20 + 4);
            text.setAttribute('font-size', '12px');
            text.textContent = series.name || `Series ${index + 1}`;
            svg.appendChild(text);
        });
    }
}

// Function to generate points for a function
function generateFunctionPoints(func, xMin, xMax, numPoints = 100) {
    const points = [];
    const step = (xMax - xMin) / (numPoints - 1);
    
    for (let i = 0; i < numPoints; i++) {
        const x = xMin + i * step;
        const y = func(x);
        if (!isNaN(y) && isFinite(y)) {
            points.push({ x, y });
        }
    }
    
    return points;
}
