// JavaScript for the Sequences page interactive elements

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the interactive sequence visualizer if it exists on the page
    initSequenceVisualizer();
});

function initSequenceVisualizer() {
    const visualizerContainer = document.getElementById('interactive-sequence-graph');
    if (!visualizerContainer) return;
    
    const sequenceSelect = document.getElementById('sequence-select');
    const termsSlider = document.getElementById('terms-slider');
    const termsValue = document.getElementById('terms-value');
    
    // Update the terms value display when the slider changes
    if (termsSlider && termsValue) {
        termsSlider.addEventListener('input', function() {
            termsValue.textContent = this.value;
            updateSequenceVisualization();
        });
    }
    
    // Update the visualization when the sequence type changes
    if (sequenceSelect) {
        sequenceSelect.addEventListener('change', function() {
            updateSequenceVisualization();
        });
    }
    
    // Initial visualization
    updateSequenceVisualization();
}

function updateSequenceVisualization() {
    const sequenceSelect = document.getElementById('sequence-select');
    const termsSlider = document.getElementById('terms-slider');
    const sequenceFormula = document.getElementById('sequence-formula');
    const sequenceConvergence = document.getElementById('sequence-convergence');
    
    if (!sequenceSelect || !termsSlider) return;
    
    const sequenceType = sequenceSelect.value;
    const numTerms = parseInt(termsSlider.value);
    
    // Generate sequence data based on the selected type
    let sequenceData = [];
    let sequenceFunction;
    let convergenceValue = '';
    let formulaText = '';
    
    // Get the selected option text to ensure correct display
    const selectedOption = sequenceSelect.options[sequenceSelect.selectedIndex].text;
    
    switch (sequenceType) {
        case '0': // 1/n
            sequenceFunction = n => 1 / (n + 1);
            formulaText = selectedOption;
            convergenceValue = 'Converges to 0';
            break;
        case '1': // n/(n+1)
            sequenceFunction = n => n / (n + 1);
            formulaText = selectedOption;
            convergenceValue = 'Converges to 1';
            break;
        case '2': // (n+1)/n^2
            sequenceFunction = n => (n + 1) / Math.pow(n + 1, 2);
            formulaText = selectedOption;
            convergenceValue = 'Converges to 0';
            break;
        case '3': // (-1)^n
            sequenceFunction = n => Math.pow(-1, n);
            formulaText = selectedOption;
            convergenceValue = 'Oscillates between -1 and 1';
            break;
        case '4': // n
            sequenceFunction = n => n + 1;
            formulaText = selectedOption;
            convergenceValue = 'Diverges to ∞';
            break;
        case '5': // 1 + 1/n
            sequenceFunction = n => 1 + 1 / (n + 1);
            formulaText = selectedOption;
            convergenceValue = 'Converges to 1';
            break;
        default:
            sequenceFunction = n => 1 / (n + 1);
            formulaText = selectedOption;
            convergenceValue = 'Converges to 0';
    }
    
    // Generate sequence points
    const points = [];
    for (let i = 0; i < numTerms; i++) {
        points.push({ x: i, y: sequenceFunction(i) });
    }
    
    // Update the visualization
    createLineChart('interactive-sequence-graph', [
        { name: 'Sequence', points: points }
    ], {
        xLabel: 'n',
        yLabel: 'a_n',
        width: document.getElementById('interactive-sequence-graph').clientWidth
    });
    
    // Update the information display
    if (sequenceFormula) {
        sequenceFormula.textContent = `Formula: ${formulaText}`;
    }
    
    if (sequenceConvergence) {
        sequenceConvergence.textContent = `Behavior: ${convergenceValue}`;
    }
    
    // Generate first 5 terms for display
    let firstTerms = [];
    for (let i = 1; i <= 5; i++) {
        firstTerms.push(sequenceFunction(i-1).toFixed(3).replace(/\.?0+$/, ''));
    }
    
    const sequenceTerms = document.getElementById('sequence-terms');
    if (sequenceTerms) {
        sequenceTerms.textContent = `First 5 terms: ${firstTerms.join(', ')}`;
    }
}
