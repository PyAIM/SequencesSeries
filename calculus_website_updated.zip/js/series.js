// JavaScript for the Series page interactive elements

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the interactive series visualizer if it exists on the page
    initSeriesVisualizer();
});

function initSeriesVisualizer() {
    const visualizerContainer = document.getElementById('interactive-series-graph');
    if (!visualizerContainer) return;
    
    const seriesSelect = document.getElementById('series-select');
    const termsSlider = document.getElementById('terms-slider');
    const termsValue = document.getElementById('terms-value');
    
    // Update the terms value display when the slider changes
    if (termsSlider && termsValue) {
        termsSlider.addEventListener('input', function() {
            termsValue.textContent = this.value;
            updateSeriesVisualization();
        });
    }
    
    // Update the visualization when the series type changes
    if (seriesSelect) {
        seriesSelect.addEventListener('change', function() {
            updateSeriesVisualization();
        });
    }
    
    // Initial visualization
    updateSeriesVisualization();
}

function updateSeriesVisualization() {
    const seriesSelect = document.getElementById('series-select');
    const termsSlider = document.getElementById('terms-slider');
    const seriesFormula = document.getElementById('series-formula');
    const seriesConvergence = document.getElementById('series-convergence');
    const partialSumValue = document.getElementById('partial-sum-value');
    
    if (!seriesSelect || !termsSlider) return;
    
    const seriesType = seriesSelect.value;
    const numTerms = parseInt(termsSlider.value);
    
    // Generate series data based on the selected type
    let termFunction;
    let formulaText = '';
    let convergenceValue = '';
    let convergenceSum = '';
    
    switch (seriesType) {
        case '1': // Geometric series (r=0.5)
            termFunction = n => Math.pow(0.5, n);
            formulaText = '\\sum_{n=0}^{\\infty} (1/2)^n';
            convergenceValue = 'Converges to 2';
            convergenceSum = '2';
            break;
        case '2': // Geometric series (r=2)
            termFunction = n => Math.pow(2, n);
            formulaText = '\\sum_{n=0}^{\\infty} 2^n';
            convergenceValue = 'Diverges to ∞';
            convergenceSum = '∞';
            break;
        case '3': // p-series (p=2)
            termFunction = n => 1 / Math.pow(n + 1, 2);
            formulaText = '\\sum_{n=0}^{\\infty} \\frac{1}{(n+1)^2}';
            convergenceValue = 'Converges to π²/6 ≈ 1.645';
            convergenceSum = 'π²/6 ≈ 1.645';
            break;
        case '4': // Harmonic series
            termFunction = n => 1 / (n + 1);
            formulaText = '\\sum_{n=0}^{\\infty} \\frac{1}{n+1}';
            convergenceValue = 'Diverges to ∞';
            convergenceSum = '∞';
            break;
        case '5': // Alternating harmonic series
            termFunction = n => Math.pow(-1, n) / (n + 1);
            formulaText = '\\sum_{n=0}^{\\infty} \\frac{(-1)^n}{n+1}';
            convergenceValue = 'Converges to ln(2) ≈ 0.693';
            convergenceSum = 'ln(2) ≈ 0.693';
            break;
        default:
            termFunction = n => 1 / (n + 1);
            formulaText = '\\sum_{n=0}^{\\infty} \\frac{1}{n+1}';
            convergenceValue = 'Diverges to ∞';
            convergenceSum = '∞';
    }
    
    // Generate term values and partial sums
    const terms = [];
    const partialSums = [];
    let sum = 0;
    
    for (let i = 0; i < numTerms; i++) {
        const term = termFunction(i);
        terms.push({ x: i, y: term });
        
        sum += term;
        partialSums.push({ x: i, y: sum });
    }
    
    // Update the visualization
    createLineChart('interactive-series-graph', [
        { name: 'Terms', points: terms },
        { name: 'Partial Sums', points: partialSums }
    ], {
        xLabel: 'n',
        yLabel: 'Value',
        width: document.getElementById('interactive-series-graph').clientWidth
    });
    
    // Update the information display
    if (seriesFormula) {
        seriesFormula.textContent = `Formula: ${formulaText}`;
    }
    
    if (seriesConvergence) {
        seriesConvergence.textContent = `Convergence: ${convergenceValue}`;
    }
    
    if (partialSumValue) {
        partialSumValue.textContent = `Partial Sum (n=${numTerms-1}): ${sum.toFixed(6)}`;
    }
    
    // Render MathJax if available
    if (typeof MathJax !== 'undefined') {
        MathJax.Hub.Queue(["Typeset", MathJax.Hub]);
    }
}
